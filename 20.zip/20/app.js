const createError = require('http-errors');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const exphbs = require('express-handlebars'); 

const indexRouter = require('./routes/index');

const app = express();

const hbs = exphbs.create({
    layoutsDir: path.join(__dirname, 'views', 'layouts'),
    extname: '.hbs',
    defaultLayout: 'layout',
    partialsDir: path.join(__dirname, 'views', 'partials'),
    helpers: {
        dismiss: function () {
            return "window.location.href = '/'";
        }
    }
});

app.engine('hbs', hbs.engine);
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);

app.use(function (req, res, next) {
    next(createError(404));
});

app.use(function (err, req, res, next) {
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};
    res.status(err.status || 500);
    res.render('error');
});

app.listen(3000, () => console.log('Сервер запущен на порту 3000'));